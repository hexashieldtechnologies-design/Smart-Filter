Secure Vault mobile source bundle

This ZIP contains the current Expo mobile app source.
It is not an installable Android APK. The current project has an Expo Go/static preview build, and no native APK binary was generated.
